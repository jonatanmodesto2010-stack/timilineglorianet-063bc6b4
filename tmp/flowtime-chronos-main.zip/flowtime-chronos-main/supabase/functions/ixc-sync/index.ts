import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version',
};

interface IXCClient {
  id: string;
  razao: string;
  ativo: string;
  bloqueado: string;
  data_cadastro?: string;
}

interface IXCFatura {
  id: string;
  id_cliente: string;
  valor: string;
  data_vencimento: string;
  status: string;
  observacao?: string;
}

function mapIxcStatus(ixcStatus: string): string {
  const statusMap: Record<string, string> = {
    'A': 'pendente',    // Aberto
    'R': 'pago',        // Recebido
    'C': 'cancelado',   // Cancelado
    'P': 'pendente',    // Pendente
  };
  return statusMap[ixcStatus] || 'pendente';
}

async function fetchIxcData(apiUrl: string, apiToken: string, endpoint: string, page: number = 1, perPage: number = 100, queryOverrides?: { qtype?: string; query?: string; oper?: string }) {
  const url = `${apiUrl}/webservice/v1/${endpoint}`;
  
  console.log(`Fetching IXC data from: ${url} (page ${page})`);
  
  const qtype = queryOverrides?.qtype || `${endpoint}.id`;
  const query = queryOverrides?.query ?? '0';
  const oper = queryOverrides?.oper || '>';
  
  const body = new URLSearchParams();
  body.append('qtype', qtype);
  body.append('query', query);
  body.append('oper', oper);
  body.append('page', page.toString());
  body.append('rp', perPage.toString());
  body.append('sortname', `${endpoint}.id`);
  body.append('sortorder', 'asc');
  
  const response = await fetch(url, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/x-www-form-urlencoded',
      'Authorization': `Basic ${apiToken}`,
      'ixcsoft': 'listar',
    },
    body: body.toString(),
  });

  const contentType = response.headers.get('content-type') || '';
  const responseText = await response.text();

  if (!response.ok) {
    console.error(`IXC API error [${response.status}]:`, responseText.substring(0, 300));
    throw new Error(`IXC API error [${response.status}]: ${responseText.substring(0, 200)}`);
  }

  if (!contentType.includes('application/json') && !contentType.includes('text/json')) {
    if (responseText.trim().startsWith('<') || responseText.includes('<html')) {
      throw new Error(
        `IXC API retornou HTML em vez de JSON. Verifique se a URL da API (${apiUrl}) e o token estão corretos.`
      );
    }
  }

  try {
    return JSON.parse(responseText);
  } catch (e) {
    throw new Error(`Resposta do IXC não é JSON válido. Preview: ${responseText.substring(0, 100)}`);
  }
}

async function checkCancelled(supabaseAdmin: any, logId: string | undefined): Promise<boolean> {
  if (!logId) return false;
  const { data } = await supabaseAdmin
    .from('integration_sync_log')
    .select('status')
    .eq('id', logId)
    .single();
  return data?.status === 'cancelled';
}

async function fetchBlockedClientIds(apiUrl: string, apiToken: string, contractsApiUrl?: string | null): Promise<Set<string>> {
  const blockedIds = new Set<string>();

  // 1. cliente_bloqueado endpoint
  let page = 1;
  let bloqueadoWorked = false;

  while (true) {
    try {
      const data = await fetchIxcData(apiUrl, apiToken, 'cliente_bloqueado', page, 500);
      const records = data.registros || data.rows || [];
      if (page === 1 && Array.isArray(records) && records.length > 0) bloqueadoWorked = true;
      if (!Array.isArray(records) || records.length === 0) break;

      for (const record of records) {
        const clientId = (record.id_cliente || record.cliente_id || record.id)?.toString();
        if (clientId) blockedIds.add(clientId);
      }

      if (records.length < 500) break;
      page++;
    } catch (err) {
      console.error('Error fetching cliente_bloqueado:', err);
      break;
    }
  }

  if (bloqueadoWorked) console.log(`Found ${blockedIds.size} blocked via cliente_bloqueado`);

  // 2. cliente_contrato - active contract but non-active internet
  const contractsUrl = contractsApiUrl || apiUrl;
  page = 1;
  let contractBlocked = 0;

  while (true) {
    try {
      const data = await fetchIxcData(contractsUrl, apiToken, 'cliente_contrato', page, 500);
      const records = data.registros || data.rows || [];
      if (!Array.isArray(records) || records.length === 0) break;

      for (const record of records) {
        const statusInternet = record.status_internet?.toString() || '';
        const status = record.status?.toString() || '';
        if (status === 'A' && statusInternet !== 'A') {
          const clientId = record.id_cliente?.toString();
          if (clientId && !blockedIds.has(clientId)) {
            blockedIds.add(clientId);
            contractBlocked++;
          }
        }
      }

      if (records.length < 500) break;
      page++;
    } catch (err) {
      console.error('Error fetching cliente_contrato:', err);
      break;
    }
  }

  console.log(`Additional blocked from contracts: ${contractBlocked}. Total blocked: ${blockedIds.size}`);
  return blockedIds;
}

async function syncClients(supabaseAdmin: any, organizationId: string, apiUrl: string, apiToken: string, logId?: string, contractsApiUrl?: string | null) {
  let page = 1;
  let totalProcessed = 0;
  let totalCreated = 0;
  let totalUpdated = 0;

  const { data: orgUser } = await supabaseAdmin
    .from('user_roles')
    .select('user_id')
    .eq('organization_id', organizationId)
    .in('role', ['owner', 'admin'])
    .limit(1)
    .single();

  if (!orgUser) {
    console.error('No admin/owner found for organization');
    return { totalProcessed: 0, totalCreated: 0, totalUpdated: 0, cancelled: false };
  }

  console.log('Fetching blocked clients...');
  const blockedClientIds = await fetchBlockedClientIds(apiUrl, apiToken, contractsApiUrl);

  while (true) {
    if (await checkCancelled(supabaseAdmin, logId)) {
      return { totalProcessed, totalCreated, totalUpdated, cancelled: true };
    }

    const data = await fetchIxcData(apiUrl, apiToken, 'cliente', page, 500);
    const records = data.registros || data.rows || [];

    if (page === 1) {
      const totalRecords = parseInt(data.total) || 0;
      console.log(`API reports total clients: ${totalRecords}`);
      if (logId) {
        await supabaseAdmin.from('integration_sync_log')
          .update({ total_records: totalRecords })
          .eq('id', logId);
      }
    }
    
    if (!Array.isArray(records) || records.length === 0) break;

    const pageClients = records
      .map((r: IXCClient) => ({ ...r, _clientId: r.id?.toString() }))
      .filter((r: any) => r._clientId);

    const clientIds = pageClients.map((r: any) => r._clientId);

    const { data: existingClients } = await supabaseAdmin
      .from('client_timelines')
      .select('id, client_id')
      .eq('organization_id', organizationId)
      .in('client_id', clientIds);

    const existingMap = new Map<string, string>();
    (existingClients || []).forEach((e: any) => existingMap.set(e.client_id, e.id));

    const toUpdate: any[] = [];
    const toInsert: any[] = [];

    for (const client of pageClients) {
      const clientId = client._clientId;
      const existingId = existingMap.get(clientId);
      const isContractActive = client.ativo === 'S';
      const isBlocked = blockedClientIds.has(clientId);
      const isActive = isContractActive && !isBlocked;
      const status = !isContractActive ? 'archived' : 'active';

      if (existingId) {
        toUpdate.push({
          id: existingId,
          client_name: client.razao || `Cliente ${clientId}`,
          is_active: isActive,
          status: status,
        });
      } else {
        toInsert.push({
          client_id: clientId,
          client_name: client.razao || `Cliente ${clientId}`,
          is_active: isActive,
          organization_id: organizationId,
          start_date: client.data_cadastro || new Date().toISOString().split('T')[0],
          status: status,
          user_id: orgUser.user_id,
        });
      }
    }

    if (toUpdate.length > 0) {
      const { error } = await supabaseAdmin.rpc('batch_upsert_clients', {
        p_ids: toUpdate.map(r => r.id),
        p_names: toUpdate.map(r => r.client_name),
        p_active: toUpdate.map(r => r.is_active),
        p_statuses: toUpdate.map(r => r.status),
      });
      if (error) console.error('Batch client update error:', error.message);
      else totalUpdated += toUpdate.length;
    }

    if (toInsert.length > 0) {
      const { error } = await supabaseAdmin
        .from('client_timelines')
        .insert(toInsert);
      if (error) console.error('Batch insert error:', error.message);
      else totalCreated += toInsert.length;
    }

    totalProcessed += pageClients.length;

    if (logId) {
      await supabaseAdmin.from('integration_sync_log')
        .update({ records_processed: totalProcessed })
        .eq('id', logId);
    }

    console.log(`Page ${page}: ${toInsert.length} created, ${toUpdate.length} updated (${totalProcessed} total)`);

    if (records.length < 500) break;
    page++;
  }

  // === Discover additional clients from cliente_contrato ===
  const contractsUrl = contractsApiUrl || apiUrl;
  const allContractClientIds = new Set<string>();
  const contractClientNames = new Map<string, string>();
  
  let cPage = 1;
  while (true) {
    if (await checkCancelled(supabaseAdmin, logId)) {
      return { totalProcessed, totalCreated, totalUpdated, cancelled: true };
    }
    
    const cData = await fetchIxcData(contractsUrl, apiToken, 'cliente_contrato', cPage, 500);
    const cRecords = cData.registros || cData.rows || [];
    if (!Array.isArray(cRecords) || cRecords.length === 0) break;
    
    for (const record of cRecords) {
      const clientId = record.id_cliente?.toString();
      if (clientId) {
        allContractClientIds.add(clientId);
        if (!contractClientNames.has(clientId)) {
          const name = record.razao || record.razao_social || record.nome || null;
          if (name) contractClientNames.set(clientId, name);
        }
      }
    }
    
    if (cRecords.length < 500) break;
    cPage++;
  }
  
  // Find missing clients
  const contractClientArray = [...allContractClientIds];
  const missingClientIds: string[] = [];
  
  for (let i = 0; i < contractClientArray.length; i += 500) {
    const batch = contractClientArray.slice(i, i + 500);
    const { data: existing } = await supabaseAdmin
      .from('client_timelines')
      .select('client_id')
      .eq('organization_id', organizationId)
      .in('client_id', batch);
    
    const existingSet = new Set((existing || []).map((e: any) => e.client_id));
    for (const cid of batch) {
      if (!existingSet.has(cid)) missingClientIds.push(cid);
    }
  }
  
  console.log(`Missing clients from contracts: ${missingClientIds.length}`);
  
  if (missingClientIds.length > 0) {
    const toInsertMissing: any[] = [];
    
    for (const clientId of missingClientIds) {
      if (await checkCancelled(supabaseAdmin, logId)) {
        return { totalProcessed, totalCreated, totalUpdated, cancelled: true };
      }
      
      try {
        const clientData = await fetchIxcData(apiUrl, apiToken, 'cliente', 1, 1, {
          qtype: 'cliente.id',
          query: clientId,
          oper: '=',
        });
        
        const records = clientData.registros || clientData.rows || [];
        
        if (Array.isArray(records) && records.length > 0) {
          const client = records[0];
          const isContractActive = client.ativo === 'S';
          const isBlocked = blockedClientIds.has(clientId);
          const isActive = isContractActive && !isBlocked;
          const status = !isContractActive ? 'archived' : 'active';
          
          toInsertMissing.push({
            client_id: clientId,
            client_name: client.razao || contractClientNames.get(clientId) || `Cliente ${clientId}`,
            is_active: isActive,
            organization_id: organizationId,
            start_date: client.data_cadastro || new Date().toISOString().split('T')[0],
            status: status,
            user_id: orgUser.user_id,
          });
        } else {
          toInsertMissing.push({
            client_id: clientId,
            client_name: contractClientNames.get(clientId) || `Cliente ${clientId}`,
            is_active: !blockedClientIds.has(clientId),
            organization_id: organizationId,
            start_date: new Date().toISOString().split('T')[0],
            status: 'active',
            user_id: orgUser.user_id,
          });
        }
      } catch (err) {
        console.error(`Error fetching client ${clientId}:`, err);
        toInsertMissing.push({
          client_id: clientId,
          client_name: contractClientNames.get(clientId) || `Cliente ${clientId}`,
          is_active: !blockedClientIds.has(clientId),
          organization_id: organizationId,
          start_date: new Date().toISOString().split('T')[0],
          status: 'active',
          user_id: orgUser.user_id,
        });
      }
    }
    
    if (toInsertMissing.length > 0) {
      for (let i = 0; i < toInsertMissing.length; i += 100) {
        const batch = toInsertMissing.slice(i, i + 100);
        const { error } = await supabaseAdmin
          .from('client_timelines')
          .insert(batch);
        if (error) console.error('Batch insert missing error:', error.message);
        else totalCreated += batch.length;
      }
      totalProcessed += toInsertMissing.length;
    }
    
    if (logId) {
      await supabaseAdmin.from('integration_sync_log')
        .update({ records_processed: totalProcessed })
        .eq('id', logId);
    }
  }

  return { totalProcessed, totalCreated, totalUpdated, cancelled: false };
}

async function syncBoletos(supabaseAdmin: any, organizationId: string, apiUrl: string, apiToken: string, logId?: string) {
  let page = 1;
  let totalProcessed = 0;
  let totalCreated = 0;
  let totalUpdated = 0;

  while (true) {
    if (await checkCancelled(supabaseAdmin, logId)) {
      return { totalProcessed, totalCreated, totalUpdated, cancelled: true };
    }

    const data = await fetchIxcData(apiUrl, apiToken, 'fn_areceber', page, 500);
    const records = data.registros || data.rows || [];

    if (page === 1 && logId) {
      const totalRecords = parseInt(data.total) || 0;
      await supabaseAdmin.from('integration_sync_log')
        .update({ total_records: totalRecords })
        .eq('id', logId);
    }
    
    if (!Array.isArray(records) || records.length === 0) break;

    const validRecords = records
      .map((r: IXCFatura) => ({ ...r, _clientId: r.id_cliente?.toString() }))
      .filter((r: any) => r._clientId);

    const uniqueClientIds = [...new Set(validRecords.map((r: any) => r._clientId))];

    // Fetch ALL timelines for these clients (not just active - blocked clients need boletos too)
    const { data: timelines } = await supabaseAdmin
      .from('client_timelines')
      .select('id, client_id')
      .eq('organization_id', organizationId)
      .in('client_id', uniqueClientIds);

    // Map client_id -> first timeline (prefer keeping one per client)
    const timelineMap = new Map<string, string>();
    (timelines || []).forEach((t: any) => {
      if (!timelineMap.has(t.client_id)) {
        timelineMap.set(t.client_id, t.id);
      }
    });

    // Deduplicate by IXC fatura ID
    const seenFaturaIds = new Set<string>();
    const validFaturas: any[] = [];
    const ixcBoletoIds: string[] = [];

    for (const fatura of validRecords) {
      const timelineId = timelineMap.get(fatura._clientId);
      if (!timelineId) continue;
      
      const ixcId = fatura.id?.toString();
      if (!ixcId) continue;
      
      const dedupeKey = `${timelineId}:${ixcId}`;
      if (seenFaturaIds.has(dedupeKey)) continue;
      seenFaturaIds.add(dedupeKey);
      
      ixcBoletoIds.push(ixcId);
      validFaturas.push({ ...fatura, _timelineId: timelineId, _ixcBoletoId: ixcId });
    }

    // Lookup existing boletos by ixc_boleto_id
    let existingMap = new Map<string, string>();
    if (ixcBoletoIds.length > 0) {
      const timelineIds = [...new Set(validFaturas.map((f: any) => f._timelineId))];
      const { data: existingBoletos } = await supabaseAdmin
        .from('client_boletos')
        .select('id, timeline_id, ixc_boleto_id')
        .in('timeline_id', timelineIds)
        .in('ixc_boleto_id', ixcBoletoIds);

      (existingBoletos || []).forEach((b: any) => {
        if (b.ixc_boleto_id) {
          existingMap.set(`${b.timeline_id}:${b.ixc_boleto_id}`, b.id);
        }
      });
    }

    const toInsert: any[] = [];
    const toUpdateList: any[] = [];

    for (const fatura of validFaturas) {
      const key = `${fatura._timelineId}:${fatura._ixcBoletoId}`;
      const existingId = existingMap.get(key);

      if (existingId) {
        toUpdateList.push({
          id: existingId,
          boleto_value: parseFloat(fatura.valor) || 0,
          due_date: fatura.data_vencimento,
          status: mapIxcStatus(fatura.status),
        });
      } else {
        toInsert.push({
          timeline_id: fatura._timelineId,
          boleto_value: parseFloat(fatura.valor) || 0,
          due_date: fatura.data_vencimento,
          status: mapIxcStatus(fatura.status),
          description: `Fatura IXC #${fatura._ixcBoletoId}`,
          ixc_boleto_id: fatura._ixcBoletoId,
        });
      }
    }

    if (toUpdateList.length > 0) {
      const { error } = await supabaseAdmin.rpc('batch_upsert_boletos', {
        p_ids: toUpdateList.map(r => r.id),
        p_values: toUpdateList.map(r => r.boleto_value),
        p_dates: toUpdateList.map(r => r.due_date),
        p_statuses: toUpdateList.map(r => r.status),
      });
      if (error) console.error('Batch boleto update error:', error.message);
      else totalUpdated += toUpdateList.length;
    }

    if (toInsert.length > 0) {
      const { error } = await supabaseAdmin
        .from('client_boletos')
        .insert(toInsert);
      if (error) console.error('Batch boleto insert error:', error.message);
      else totalCreated += toInsert.length;
    }

    totalProcessed += validRecords.length;

    if (logId) {
      await supabaseAdmin.from('integration_sync_log')
        .update({ records_processed: totalProcessed })
        .eq('id', logId);
    }

    console.log(`Boletos page ${page}: ${toInsert.length} created, ${toUpdateList.length} updated (${totalProcessed} total)`);

    if (records.length < 500) break;
    page++;
  }

  return { totalProcessed, totalCreated, totalUpdated, cancelled: false };
}

// Helper: resolve IXC credentials and clean URLs for an organization
async function resolveIxcCredentials(supabaseAdmin: any, organizationId: string) {
  const { data: integrationConfig } = await supabaseAdmin
    .from('organization_integrations')
    .select('api_url, api_url_contracts, api_token')
    .eq('organization_id', organizationId)
    .eq('integration_type', 'ixc')
    .maybeSingle();

  const ixcApiUrl = integrationConfig?.api_url || Deno.env.get('IXC_API_URL');
  const ixcApiToken = integrationConfig?.api_token || Deno.env.get('IXC_API_TOKEN');

  if (!ixcApiUrl || !ixcApiToken) return null;

  const cleanUrl = ixcApiUrl.replace(/\/+$/, '').replace(/\/[^\/]*\.(php|html?)$/i, '').replace(/\/(app|admin|adm|webservice).*$/i, '');
  const ixcApiUrlContracts = integrationConfig?.api_url_contracts;
  const cleanUrlContracts = ixcApiUrlContracts 
    ? ixcApiUrlContracts.replace(/\/+$/, '').replace(/\/[^\/]*\.(php|html?)$/i, '').replace(/\/(app|admin|adm|webservice).*$/i, '')
    : null;

  // Auto-encode token
  let finalToken = ixcApiToken;
  try {
    const decoded = atob(ixcApiToken);
    if (!decoded.includes(':')) {
      finalToken = btoa(ixcApiToken + ':');
    }
  } catch {
    finalToken = ixcApiToken.includes(':') ? btoa(ixcApiToken) : btoa(ixcApiToken + ':');
  }

  return { cleanUrl, cleanUrlContracts, finalToken };
}

async function runSyncForOrganization(supabaseAdmin: any, organizationId: string, syncType: string) {
  const creds = await resolveIxcCredentials(supabaseAdmin, organizationId);
  if (!creds) {
    console.log(`No IXC credentials for org ${organizationId}, skipping`);
    return null;
  }

  const results: any = {};

  if (syncType === 'clients' || syncType === 'all') {
    const { data: logEntry } = await supabaseAdmin
      .from('integration_sync_log')
      .insert({ organization_id: organizationId, sync_type: 'clients', status: 'running' })
      .select('id')
      .single();

    try {
      const clientResult = await syncClients(supabaseAdmin, organizationId, creds.cleanUrl, creds.finalToken, logEntry?.id, creds.cleanUrlContracts);
      results.clients = clientResult;
      
      if (logEntry && !clientResult.cancelled) {
        await supabaseAdmin.from('integration_sync_log')
          .update({
            status: 'success',
            records_processed: clientResult.totalProcessed,
            records_created: clientResult.totalCreated,
            records_updated: clientResult.totalUpdated,
            completed_at: new Date().toISOString(),
          })
          .eq('id', logEntry.id);
      }
    } catch (err) {
      if (logEntry) {
        await supabaseAdmin.from('integration_sync_log')
          .update({
            status: 'error',
            error_message: err instanceof Error ? err.message : 'Unknown error',
            completed_at: new Date().toISOString(),
          })
          .eq('id', logEntry.id);
      }
      throw err;
    }
  }

  if (syncType === 'boletos' || syncType === 'all') {
    const { data: logEntry } = await supabaseAdmin
      .from('integration_sync_log')
      .insert({ organization_id: organizationId, sync_type: 'boletos', status: 'running' })
      .select('id')
      .single();

    try {
      const boletoResult = await syncBoletos(supabaseAdmin, organizationId, creds.cleanUrl, creds.finalToken, logEntry?.id);
      results.boletos = boletoResult;
      
      if (logEntry && !boletoResult.cancelled) {
        await supabaseAdmin.from('integration_sync_log')
          .update({
            status: 'success',
            records_processed: boletoResult.totalProcessed,
            records_created: boletoResult.totalCreated,
            records_updated: boletoResult.totalUpdated,
            completed_at: new Date().toISOString(),
          })
          .eq('id', logEntry.id);
      }
    } catch (err) {
      if (logEntry) {
        await supabaseAdmin.from('integration_sync_log')
          .update({
            status: 'error',
            error_message: err instanceof Error ? err.message : 'Unknown error',
            completed_at: new Date().toISOString(),
          })
          .eq('id', logEntry.id);
      }
      throw err;
    }
  }

  return results;
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseAnonKey = Deno.env.get('SUPABASE_ANON_KEY')!;
    const serviceRoleKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabaseAdmin = createClient(supabaseUrl, serviceRoleKey);

    // === CRON MODE: no auth header = automated cron invocation ===
    const authHeader = req.headers.get('Authorization');
    
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      // Cron mode: sync ALL organizations that have active IXC integrations
      console.log('[CRON] Starting automated IXC sync for all organizations');
      
      const { data: activeIntegrations } = await supabaseAdmin
        .from('organization_integrations')
        .select('organization_id')
        .eq('integration_type', 'ixc')
        .eq('is_active', true);

      if (!activeIntegrations || activeIntegrations.length === 0) {
        return new Response(JSON.stringify({ message: 'No active IXC integrations found' }), {
          status: 200, headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });
      }

      const allResults: any = {};
      for (const integration of activeIntegrations) {
        try {
          console.log(`[CRON] Syncing org: ${integration.organization_id}`);
          allResults[integration.organization_id] = await runSyncForOrganization(
            supabaseAdmin, integration.organization_id, 'all'
          );
        } catch (err) {
          console.error(`[CRON] Error syncing org ${integration.organization_id}:`, err);
          allResults[integration.organization_id] = { error: err instanceof Error ? err.message : 'Unknown error' };
        }
      }

      return new Response(JSON.stringify({ success: true, cron: true, results: allResults }), {
        status: 200, headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    // === MANUAL MODE: user-triggered sync ===
    const supabaseUser = createClient(supabaseUrl, supabaseAnonKey, {
      global: { headers: { Authorization: authHeader } }
    });

    const { data: { user }, error: userError } = await supabaseUser.auth.getUser();
    if (userError || !user) {
      return new Response(JSON.stringify({ error: 'Unauthorized' }), { 
        status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
      });
    }

    const { data: userRole } = await supabaseAdmin
      .from('user_roles')
      .select('organization_id, role')
      .eq('user_id', user.id)
      .limit(1)
      .single();

    if (!userRole) {
      return new Response(JSON.stringify({ error: 'User has no organization' }), { 
        status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
      });
    }

    if (!['owner', 'admin'].includes(userRole.role)) {
      return new Response(JSON.stringify({ error: 'Insufficient permissions' }), { 
        status: 403, headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
      });
    }

    const { syncType } = await req.json();
    
    if (!['clients', 'boletos', 'all', 'test'].includes(syncType)) {
      return new Response(JSON.stringify({ error: 'Invalid sync type' }), { 
        status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
      });
    }

    const organizationId = userRole.organization_id;
    const creds = await resolveIxcCredentials(supabaseAdmin, organizationId);

    if (!creds) {
      return new Response(JSON.stringify({ error: 'Credenciais IXC não configuradas.' }), { 
        status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
      });
    }

    // Test mode
    if (syncType === 'test') {
      try {
        const testData = await fetchIxcData(creds.cleanUrl, creds.finalToken, 'cliente', 1, 1);
        const records = testData.registros || testData.rows || [];
        return new Response(JSON.stringify({ 
          success: true, 
          message: `Conexão OK! ${Array.isArray(records) ? records.length : 0} registro(s) retornado(s).`,
          totalRecords: testData.total || 0,
        }), {
          status: 200, headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });
      } catch (err) {
        return new Response(JSON.stringify({ 
          success: false, 
          error: err instanceof Error ? err.message : 'Erro ao testar conexão',
        }), {
          status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });
      }
    }

    const results = await runSyncForOrganization(supabaseAdmin, organizationId, syncType);

    return new Response(JSON.stringify({ success: true, results }), {
      status: 200, headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });

  } catch (error) {
    console.error('IXC Sync error:', error);
    return new Response(JSON.stringify({ 
      error: error instanceof Error ? error.message : 'Unknown error' 
    }), {
      status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});
